function [H] = multi_entropy(p)
% MULTI_ENTROPY - Compute H(P(X)) for discrete multi-valued X.
%
% Usage:
% 
%    H = multi_entropy(P)
%
%  Returns the entropy H = -\sum_x p(x) * log(p(x)).
%  For an K X N matrix P, H is a 1 x N vector of entropy for each of the 
%  N distributions over K values.

% YOUR CODE GOES HERE
%P=1/size(p,1)*sum(p,1)
%H=-sum(P.*log2(P))
H=binary_entropy(1/size(p,1)*sum(p,1));